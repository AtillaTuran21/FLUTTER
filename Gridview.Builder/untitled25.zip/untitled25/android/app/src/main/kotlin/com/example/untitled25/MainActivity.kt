package com.example.untitled25

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
