import 'package:flutter/material.dart';
import './sinif.dart';

class sayfa2 extends StatefulWidget {
  //const sayfa2({super.key});
  List<Aktarma> liste = [];
  sayfa2({super.key, required this.liste});
  int tekrar=0;
  @override
  State<sayfa2> createState() => _sayfa2State();
}

class _sayfa2State extends State<sayfa2> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Container(
            width: 800,
            height: 800,
            child: ListView.builder(
              itemCount: widget.liste.length,
              itemBuilder: (context, int index) {
                return Column(
                  children: [
                    Container(
                      child: ListTile(
                          title: Text(widget.liste[index].baslik.toString()),

                          leading: Image(
                            image: AssetImage(widget.liste[index].resim.toString()),
                          ),
                        trailing: Text(widget.liste[index].fiyat.toString()),
                      ),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                              color: Colors.black,
                              width: 2,
                              style: BorderStyle.solid)),
                      margin: EdgeInsets.fromLTRB(0, 0, 0, 20),
                    ),
                  ],
                );
              },
            ),
          ),
          Container(
            child: Row(
              children: [
                TextButton(
                    onPressed: () {
                      setState(() {});
                    },
                    child: Text("ÖDE")),
                Text(widget.liste[widget.liste.length-1].hesap.toString()),
              ],
            ),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                    color: Colors.black,
                    width: 2,
                    style: BorderStyle.solid)),
          ),
        ],
      ),
    );
  }
}
