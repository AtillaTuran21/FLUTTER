import 'package:flutter/material.dart';
import './sayfa2.dart';
import './sinif.dart';

class uygulama extends StatefulWidget {
  const uygulama({super.key});

  @override
  State<uygulama> createState() => _uygulamaState();
}

class _uygulamaState extends State<uygulama> {
  @override
  List<Color> sepetRenk = [
    Colors.black,
    Colors.black,
    Colors.black,
    Colors.black,
    Colors.black,
    Colors.black,
  ];
  List<String> resimler = [
    "images/3.png",
    "images/et.PNG",
    "images/jordan-max-aura.png",
    "images/jordan-stay-loyal.png",
    "images/karpuz.png",
    "images/tatum-1-old-school.png",
  ];
  List<String> basliklar = [
    "Robot",
    "Et",
    "Jordan Max Aura",
    "Jordan Stay Loyal",
    "Karpuz",
    "Tatum 1 Old School",
  ];
  int hesap = 0;
  List<int> altBasliklar = [2000, 500, 3000, 4000, 100, 2100];
  int kontrol = 0;
  List<Aktarma> liste = [];
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 800,
          height: 800,
          child: GridView.builder(
              itemCount: 6,
              gridDelegate:
                  SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3),
              itemBuilder: (context, index) {
                return Container(
                  child: Column(
                    children: [

                        IconButton(
                            icon: Icon(Icons.shopping_basket_outlined,
                                color: sepetRenk[index]),
                            padding: EdgeInsets.fromLTRB(110, 0, 0, 0),
                            splashRadius: 1,
                            onPressed: () {
                              setState(() {
                                sepetRenk[index] = Colors.orange;
                                print(index);
                                if (index == 0) {
                                  hesap = hesap + altBasliklar[0];
                                  liste.add(Aktarma(
                                      baslik: basliklar[0],
                                      fiyat: altBasliklar[0],
                                      resim: resimler[0],
                                      hesap: hesap));
                                }
                                if (index == 1) {
                                  hesap = hesap + altBasliklar[1];
                                  liste.add(Aktarma(
                                      baslik: basliklar[1],
                                      fiyat: altBasliklar[1],
                                      resim: resimler[1],
                                      hesap: hesap));
                                }
                                if (index == 2) {
                                  hesap = hesap + altBasliklar[2];
                                  liste.add(Aktarma(
                                      baslik: basliklar[2],
                                      fiyat: altBasliklar[2],
                                      resim: resimler[2],
                                      hesap: hesap));
                                }
                                if (index == 3) {
                                  hesap = hesap + altBasliklar[3];
                                  liste.add(Aktarma(
                                      baslik: basliklar[3],
                                      fiyat: altBasliklar[3],
                                      resim: resimler[3],
                                      hesap: hesap));
                                }
                                if (index == 4) {
                                  hesap = hesap + altBasliklar[4];
                                  liste.add(Aktarma(
                                      baslik: basliklar[4],
                                      fiyat: altBasliklar[4],
                                      resim: resimler[4],
                                      hesap: hesap));
                                }
                                if (index == 5) {
                                  hesap = hesap + altBasliklar[5];
                                  liste.add(Aktarma(
                                      baslik: basliklar[5],
                                      fiyat: altBasliklar[5],
                                      resim: resimler[5],
                                      hesap: hesap));
                                }
                              });
                            }),

                      Image.asset(resimler[index], height: 60),
                      Text(basliklar[index]),
                      Text(altBasliklar[index].toString()),
                    ],
                  ),
                  margin: EdgeInsets.all(6),
                  decoration: BoxDecoration(
                      color: Colors.transparent,
                      border: Border.all(
                        color: Colors.black,
                      )),
                );
              }),
        ),
        Container(
          child: TextButton(
              onPressed: () {
                setState(() {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => sayfa2(
                            liste: liste,
                          )));
                });
              },
              child: Text("Sepete Git")),
          margin: EdgeInsets.fromLTRB(50, 0, 0, 0),
        ),
      ],
    );
  }
}
