import 'package:flutter/material.dart';
import './sayfa1.dart';

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Scaffold(
      body: uygulama(),
    ),
  ));
}

class buton extends StatefulWidget {
  const buton({super.key});

  @override
  State<buton> createState() => _butonState();
}

class _butonState extends State<buton> {
  @override
  Widget build(BuildContext context) {
    return TextButton(
        onPressed: () {
          setState(() {

          });
        },
        child: Text("Sepete Git"));
  }
}
