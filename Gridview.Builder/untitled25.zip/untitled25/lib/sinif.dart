class Aktarma {
  String? baslik;
  int? fiyat;
  String? resim;
  int? hesap;
  Aktarma({this.baslik,this.fiyat,this.resim,this.hesap});
}