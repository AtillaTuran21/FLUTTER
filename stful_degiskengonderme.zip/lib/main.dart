import 'package:flutter/material.dart';
import 'Anasayfa.dart.';

void main() {

  runApp(MaterialApp(debugShowCheckedModeBanner:false, home:
   Anasayfa(),
  ));
}



