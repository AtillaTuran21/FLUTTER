package com.example.uyg7

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
